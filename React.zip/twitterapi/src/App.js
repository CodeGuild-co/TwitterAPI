import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>TheySaidWhat?!?</h1>
        <form>
        <label>
          <div id='hashtag'>Hashtag:</div>
          <input id='formBox' type="text" name="name" />
        </label>
          <input
          id='submit-button' 
          type="submit" 
          value="Submit"
          />
      </form>
      </header>
    </div>
  );
}

export default App;
