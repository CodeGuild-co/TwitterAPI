# Python 3.6.9

import twitter
from textblob import TextBlob
from datetime import date, timedelta, datetime
import math
import numpy as np
from flask import Flask, request, render_template

app = Flask(__name__)

api = twitter.Api(consumer_key='TErus3u1UOUgdR6AKhIaaE9Wg',
                  consumer_secret='UI8yW0epbpuX9CxNl91eSVCGtmDh9IBkUvopH2TvPIaLjVgOCy',
                  access_token_key='1234781863597760512-SAmWryVIvcqjHM44kTbHhTS0SFExu6',
                  access_token_secret='QPigS2G8RF6wtxiVROnwTAzduh16CuewaBtgOgQdAa5Zv',
                  sleep_on_rate_limit=True,
                  tweet_mode='extended')

def find_nearest(array, value):
  array = np.asarray(array)
  idx = (np.abs(array - value)).argmin()
  return idx

def update_polarities(topic):
  dates = []
  avg_polarities = []
  big_opinions = []

  try:
    with open(f'{topic}.txt', 'r') as f:
      lines = f.read().splitlines()
      lastline = lines[len(lines) - 1]
      lastdate = datetime.strptime(lastline.split("<~>")[0], "%Y-%m-%d").date()
      delta = min((date.today() - lastdate).days, 7)
  except (FileNotFoundError, IndexError):
    delta = 7

  for i in range(delta):
    polarities = []
    big_opinion = ''

    today = (date.today() + timedelta(days=-i)).strftime("%Y-%m-%d")
    yesterday = (date.today() + timedelta(days=-i-1)).strftime("%Y-%m-%d")
    results = api.GetSearch(term=topic, lang='en', since=yesterday, until=today, count=100)

    for result in results:
      text = result.full_text.replace('&amp;', '&')
      polarity = TextBlob(text).sentiment.polarity  # * math.log(1 + result.favorite_count)
      if polarity != 0:
        polarities.append(polarity)

    dates.append(today)
    if len(polarities) > 0:
      avg = (sum(polarities) / len(polarities))
      avg_polarities.append(avg)
      big_opinion = results[find_nearest(polarities, avg)].full_text
    else:
      avg_polarities.append(0)

    big_opinions.append(ascii(big_opinion.replace("\n", "\\n")))

  avg_polarities = [x for x in avg_polarities if x != 0][::-1]
  dates = dates[:len(avg_polarities)][::-1]
  big_opinions = big_opinions[:len(avg_polarities)][::-1]

  with open(f'{topic}.txt', 'a') as f:
    for i in range(len(dates)):
      f.write(f"{dates[i]}<~>{avg_polarities[i]}<~>{big_opinions[i]}\n")

def read_polarities(hashtag):
  dates = []
  sentiments = []
  opinions = []
  with open(f'{hashtag}.txt', 'r') as f:
    lines = f.read().splitlines()
    for line in lines:
      [date, sentiment, opinion] = line.split("<~>")
      dates.append(date)
      sentiments.append(float(sentiment))
      opinions.append(opinion)
  return (dates, sentiments, opinions)

@app.route('/')
def analyse_hashtag():
  dates = None
  sentiments = None
  opinions = None
  hashtag = request.args.get('hashtag')
  if hashtag != None:
    update_polarities(hashtag)
    (dates, sentiments, opinions) = read_polarities(hashtag)
  return render_template('index.j2', hashtag=hashtag, dates=dates, sentiments=sentiments, opinions=opinions)