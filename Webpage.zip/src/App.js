import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>TheySaidWhat?!?</h1>
        <table>
          <thead>
            <td></td>
            <td id='hashtag'>Hashtag:</td>
            <td></td>
          </thead>
          <tr>
            <td id='hashsymbol'>#</td>
            <td colSpan="2">  
              <form>
              <label>
                <input id='formBox' type="text" name="name" />
              </label>
              <input
                id='submit-button' 
                type="submit" 
                value="Submit"
              />
            </form>
          </td>
        </tr>
      </table>
      </header>
    </div>
  );
}

export default App;